﻿Imports MySql.Data.MySqlClient

Public Class frmLogin
    Dim conn As New MySqlConnection
    Dim comm As MySqlCommand


    Private Sub OK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK.Click
        conn.ConnectionString = "server=localhost;userid=root;password=;database=hbrs_db;"
        Dim reader As MySqlDataReader

        Try
            conn.Open()
            Dim query As String
            query = "select * from users where Username='" & UsernameTextBox.Text & "' and Password='" & PasswordTextBox.Text & "' "
            comm = New MySqlCommand(query, conn)
            reader = comm.ExecuteReader
            Dim count As Integer
            count = 0
            While reader.Read
                count += 1
            End While

            If count = 1 Then
                MessageBox.Show("Login Successful")
                Me.Hide()
                frmMain.ShowDialog()
                UsernameTextBox.Clear()
                PasswordTextBox.Clear()
            ElseIf count > 1 Then
            Else
                MessageBox.Show("Login Failed")
            End If

            conn.Close()

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            conn.Dispose()
        End Try

    End Sub

    Private Sub Cancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel.Click
        Me.Close()
        End
    End Sub

End Class
