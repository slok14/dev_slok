﻿Imports MySql.Data.MySqlClient

Public Class frmCheckin
    Dim conn As New MySqlConnection
    Dim comm As MySqlCommand

    Private Sub bttnCheckIn_Click(sender As Object, e As EventArgs) Handles bttnCheckIn.Click
        conn.ConnectionString = "server=localhost;userid=root;password=;database=hbrs_db;"
        Dim reader As MySqlDataReader

        Try
            conn.Open()
            Dim query As String
            query = "insert into hbrs_db.checkin (TransactionID, Guest Name, Room Number, Room Type, Room Rate, Checkin Date, Checkout Date, NoofDays, NoofAdults, NoofChildrens, Discount Type, Sub Total, Advance Payment,Total Balance) values('" & txtTransID.Text & "', '" & txtGuestName.Text & "','" & txtRoomNumber.Text & "','" & txtRoomType.Text & "','" & txtRoomRate.Text & "','" & dtCheckInDate.Text & "','" & dtCheckOutDate.Text & "','" & txtDaysNumber.Text & "','" & txtAdults.Text & "','" & txtChildren.Text & "', '" & cboDiscount.Text & "', '" & txtSubTotal.Text & "', '" & txtAdvance.Text & "', '" & txtTotal.Text & "',) "
            comm = New MySqlCommand(query, conn)
            reader = comm.ExecuteReader
            MessageBox.Show("Checkin Completed")

            conn.Close()

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            conn.Dispose()
        End Try
    End Sub

    Private Sub bttnCancel_Click(sender As Object, e As EventArgs) Handles bttnCancel.Click
        Dim out_app As String = MsgBox("Cancel Check-in?", vbQuestion + vbYesNo, "Check-In")
        If out_app = vbYes Then
            Me.Close()
        End If

    End Sub

End Class