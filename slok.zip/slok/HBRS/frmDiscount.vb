﻿Imports MySql.Data.MySqlClient

Public Class frmDiscount
    Dim update_discount As Boolean = False
    Dim distype As String
    Dim disrate As Integer

    Private Sub bttnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bttnCancel.Click
        clear_txt()
        update_discount = False
        Dim out_app As String = MsgBox("Cancel Discount?", vbQuestion + vbYesNo, "Discount")
        If out_app = vbYes Then
            Me.Close()
        End If

    End Sub

    Private Sub bttnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bttnSave.Click

        If comboxType.Text = Nothing Or comboxRate.Text Then
            MsgBox("Fill All Fields!", vbInformation, "Note")
            Exit Sub
        End If
        Dim a As String = MsgBox("Save Discount Info?", vbQuestion + vbYesNo, "Save")
        If a = vbYes Then
            distype = comboxType.Text
            disrate = comboxRate.Text
        Else
            MsgBox("Data saved successfully!", vbInformation, "Discount")
            clear_txt()
        End If

    End Sub

    Private Sub clear_txt()
        comboxType.Dispose()
        comboxRate.Dispose()
        update_discount = False
    End Sub

End Class